1. requires libraries and headers from c28 control suite
2. fix the project path variable include the necessary headers and library on the search path