//Add Watch window Variables
expRemoveAll
expAdd "LoopCount" getNatural()
expAdd "ErrorCount" getNatural()
