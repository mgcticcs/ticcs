#ifndef SERIAL_CMD_MONITOR_H_
#define SERIAL_CMD_MONITOR_H_

void ClearBufferRelatedParam();
void receivedDataCommand(unsigned char d);

#endif
